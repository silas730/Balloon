
  TruStability HSC and SSC pressure sensor library for the Arduino.

  This library implements the following features:

   - read raw pressure and temperature count values
   - compute absolute pressure and temperature

  Author:          Petre Rodan <2b4eda@subdimension.ro>
  Available from:  https://github.com/rodan/honeywell_hsc_ssc_i2c
  License:         GNU GPLv3

  Honeywell High Accuracy Ceramic (HSC) and Standard Accuracy Ceramic 
  (SSC) Series are piezoresistive silicon pressure sensors.

  Updated for VTC astronomy club by Sam Newmarco <snewmarco42@gmail.com> on 11/14/2019
  
  pins for HSCDANN001BA2A3 sensor:

  1 - GND
  2 - Vcc - 3.3V
  3 - SDA - pin A4 on arduino uno/nano 
  4 - SCL - pin A5 on arduino uno/nano 
  5-8 NC. do not use.
